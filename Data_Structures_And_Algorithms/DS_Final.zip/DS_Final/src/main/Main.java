package main;

import java.util.Scanner;

import campus.event.EventRegistrationMain;
import campus.event.EventRegistrationManager;
import campus.locker.LockerMain;
import campus.locker.LockerManager;
import campus.lostfound.LostFoundMain;
import campus.lostfound.LostFoundManager;
import campus.roombooking.RoomBookingMain;
import campus.roombooking.RoomBookingManager;
import campus.studentHelp.Graph;
import campus.studentHelp.StudentHelpMain;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		LostFoundManager lostFoundManager = new LostFoundManager();
		LostFoundMain lostFoundMain = new LostFoundMain();
		RoomBookingMain roomBookingMain = new RoomBookingMain();
		RoomBookingManager roomBookingManager = new RoomBookingManager();
		Graph studentGraph = new Graph(6);
		StudentHelpMain studentHelp = new StudentHelpMain();
		EventRegistrationManager eventManager = new EventRegistrationManager();
		EventRegistrationMain eventMain = new EventRegistrationMain();
		LockerManager lockerManager = new LockerManager();
		LockerMain lockerMain = new LockerMain();

		while (true) {
			System.out.println("\n===== Campus Management System =====");
			System.out.println("1. Lost & Found Items");
			System.out.println("2. Room Booking System");
			System.out.println("3. Student Orientation Help");
			System.out.println("4. Event Participation Registration");
			System.out.println("5. Locker Management");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();

			switch (choice) {
			case 1:
				lostFoundMain.start(scanner, lostFoundManager);
				break;
			case 2:
				roomBookingMain.start(scanner, roomBookingManager);
				break;
			case 3:
				studentHelp.start(scanner, studentGraph);
				break;
			case 4:
				eventMain.start(scanner, eventManager);
				break;
			case 5:
				lockerMain.start(scanner, lockerManager);
				break;
			case 6:
				System.out.println("Exiting system. Goodbye!");
				return;
			default:
				System.out.println("Invalid choice! Please enter a number from 1 to 5.");
			}
		}
	}
}
