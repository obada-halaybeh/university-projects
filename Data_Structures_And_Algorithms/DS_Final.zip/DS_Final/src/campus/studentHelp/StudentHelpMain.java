package campus.studentHelp;

import java.util.Scanner;

public class StudentHelpMain {

	public void start(Scanner scanner, Graph graph) {
		while (true) {
			System.out.println("\n--- Student Orientation Help ---");
			System.out.println("1. Find shortest path");
			System.out.println("2. Back to Main Menu");
			System.out.print("Enter your choice: ");
			int option = scanner.nextInt();

			if (option == 1) {
				graph.printBuildings();
				System.out.println("Select source building:");
				int source = scanner.nextInt();

				
				graph.printBuildings();
				System.out.println("Select destination building:");
				int destination = scanner.nextInt();

				graph.dijkstra(source, destination);
			} else if (option == 2) {
				break;
			} else {
				System.out.println("Invalid option. Please try again.");
			}
		}
	}
}
