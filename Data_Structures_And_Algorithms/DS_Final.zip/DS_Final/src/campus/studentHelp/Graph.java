package campus.studentHelp;

public class Graph {
	private int[][] costMatrix;
	private int numberOfNodes;
	private final int INF = Integer.MAX_VALUE;

	public Graph(int numberOfNodes) {
		this.numberOfNodes = numberOfNodes;
		costMatrix = new int[numberOfNodes][numberOfNodes];

		for (int i = 0; i < numberOfNodes; i++) {
			for (int j = 0; j < numberOfNodes; j++) {
				if (i == j) {
					costMatrix[i][j] = 0;
				} else {
					costMatrix[i][j] = INF;
				}
			}
		}

		addEdge(0, 1, 2); // Main Gate – Library
		addEdge(0, 3, 4); // Main Gate – IT
		addEdge(1, 2, 3); // Library – Cafeteria
		addEdge(1, 4, 6); // Library – Engineering
		addEdge(2, 4, 1); // Cafeteria – Engineering
		addEdge(2, 5, 5); // Cafeteria – Dorm
		addEdge(3, 4, 2); // IT – Engineering
		addEdge(4, 5, 3); // Engineering – Dorm
	}

	public void addEdge(int from, int neighbor, int cost) {
		costMatrix[from][neighbor] = cost;
		costMatrix[neighbor][from] = cost;
	}

	public boolean isNeighbor(int i, int j) {
		return costMatrix[i][j] != INF;
	}

	public void dijkstra(int start, int end) {
		int[] cost = new int[numberOfNodes];
		boolean[] visited = new boolean[numberOfNodes];
		int[] prev = new int[numberOfNodes];

		for (int i = 0; i < numberOfNodes; i++) {
			cost[i] = INF;
			visited[i] = false;
			prev[i] = -1;
		}

		cost[start] = 0;

		for (int i = 0; i < numberOfNodes - 1; i++) {
			int minNode = -1;
			int minCost = INF;

			for (int j = 0; j < numberOfNodes; j++) {
				if (!visited[j] && cost[j] < minCost) {
					minCost = cost[j];
					minNode = j;
				}
			}

			if (minNode == -1)
				break;
			visited[minNode] = true;

			for (int neighbor = 0; neighbor < numberOfNodes; neighbor++) {
				if (!visited[neighbor] && isNeighbor(minNode, neighbor)) {
					int newCost = cost[minNode] + costMatrix[minNode][neighbor];
					if (newCost < cost[neighbor]) {
						cost[neighbor] = newCost;
						prev[neighbor] = minNode;
					}
				}
			}
		}

		if (cost[end] == INF) {
			System.out.println("No path found.");
		} else {
			System.out.println("Minimum cost: " + cost[end]);
			System.out.print("Path: ");
			printPath(prev, end);
			System.out.println();
		}
	}

	private void printPath(int[] prev, int node) {
		if (prev[node] != -1) {
			printPath(prev, prev[node]);
			System.out.print(" -> ");
		}
		System.out.print(getName(node));
	}

	private String getName(int index) {
		String[] names = { "Main Gate", "Library", "Cafeteria", "IT", "Engineering", "Dorm" };
		return names[index];
	}

	public void printBuildings() {
		String[] names = { "Main Gate", "Library", "Cafeteria", "IT", "Engineering", "Dorm" };
		for (int i = 0; i < names.length; i++) {
			System.out.println(i + " - " + names[i]);
		}
	}
}
