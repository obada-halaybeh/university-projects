package campus.roombooking;

import campus.adts.ArrayList;
import campus.adts.LinkedQueue;
import campus.undoRedoSystem.Action;
import campus.undoRedoSystem.UndoRedoManager;


public class RoomBookingManager {

    private ArrayList<BookingRequest> unsortedlist = new ArrayList<>(100);
    private LinkedQueue<BookingRequest> queue = new LinkedQueue<>();
    private UndoRedoManager undoRedo = new UndoRedoManager();

    public void addRequest(String name, String room, String date, int priority) {
        BookingRequest request = new BookingRequest(name, room, date, priority);
        unsortedlist.add(request);
        undoRedo.recordAction(new Action("add", request));
        System.out.println("Booking request added: " + request);
    }

    public void sortAndQueue() {
        ArrayList<BookingRequest> sortedlist = mergeSort(unsortedlist);
        queue = new LinkedQueue<>();

        for (int i = 0; i < sortedlist.size(); i++) {
            queue.enqueue(sortedlist.get(i));
        }

        System.out.println("Requests are sorted and put in the queue.");
    }

    public void processNextRequest() {
        if (queue.isEmpty()) {
            System.out.println("No requests to process");
        } else {
            BookingRequest processed = queue.dequeue();
            undoRedo.recordAction(new Action("process", processed));
            System.out.println("Processing: " + processed);
        }
    }

    public void viewQueue() {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Booking queue:");
            LinkedQueue<BookingRequest> temp = new LinkedQueue<>();
            while (!queue.isEmpty()) {
                BookingRequest info = queue.dequeue();
                System.out.println(info);
                temp.enqueue(info);
            }
            while (!temp.isEmpty()) {
                queue.enqueue(temp.dequeue());
            }
        }
    }

    public void viewUnsorted() {
        if (unsortedlist.size() == 0) {
            System.out.println("No unsorted requests");
            return;
        }
        System.out.println("Unsorted Requests:");
        for (int i = 0; i < unsortedlist.size(); i++) {
            System.out.println(unsortedlist.get(i));
        }
    }


    public void undo() {
        Action action = undoRedo.undo();
        if (action == null) return;

        BookingRequest req = (BookingRequest) action.getData();
        switch (action.getType()) {
            case "add":

                for (int i = 0; i < unsortedlist.size(); i++) {
                    if (unsortedlist.get(i).getId() == req.getId()) {
                        unsortedlist.remove(i);
                        System.out.println("Undo: removed booking request " + req);
                        return;
                    }
                }
                break;

            case "process":
                queue.enqueue(req);
                System.out.println("Undo: re-added processed request " + req);
                break;
        }
    }

    public void redo() {
        Action action = undoRedo.redo();
        if (action == null) return;

        BookingRequest req = (BookingRequest) action.getData();
        switch (action.getType()) {
            case "add":
                unsortedlist.add(req);
                System.out.println("Redo: re-added booking request " + req);
                break;

            case "process":

                LinkedQueue<BookingRequest> temp = new LinkedQueue<>();
                boolean removed = false;
                while (!queue.isEmpty()) {
                    BookingRequest current = queue.dequeue();
                    if (!removed && current.getId() == req.getId()) {
                        removed = true; 
                    } else {
                        temp.enqueue(current);
                    }
                }
                while (!temp.isEmpty()) {
                    queue.enqueue(temp.dequeue());
                }

                System.out.println("Redo: processed request again: " + req);
                break;
        }
    }

    //Merge Sort 

    private ArrayList<BookingRequest> mergeSort(ArrayList<BookingRequest> list) {
        if (list.size() <= 1) {
            return list;
        }

        int mid = list.size() / 2;
        ArrayList<BookingRequest> left = new ArrayList<>(mid);
        ArrayList<BookingRequest> right = new ArrayList<>(list.size() - mid);

        for (int i = 0; i < mid; i++) {
            left.add(list.get(i));
        }
        for (int i = mid; i < list.size(); i++) {
            right.add(list.get(i));
        }

        return merge(mergeSort(left), mergeSort(right));
    }

    private ArrayList<BookingRequest> merge(ArrayList<BookingRequest> left, ArrayList<BookingRequest> right) {
        ArrayList<BookingRequest> result = new ArrayList<>(left.size() + right.size());
        int i = 0, j = 0;

        while (i < left.size() && j < right.size()) {
            if (left.get(i).getPriority() <= right.get(j).getPriority()) {
                result.add(left.get(i++));
            } else {
                result.add(right.get(j++));
            }
        }

        while (i < left.size()) {
            result.add(left.get(i++));
        }

        while (j < right.size()) {
            result.add(right.get(j++));
        }

        return result;
    }
}
