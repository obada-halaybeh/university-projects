package campus.roombooking;

public class BookingRequest {

    private static int counter = 1;
    private int id;

    private String studentName;
    private String room;
    private String date;
    private int priority;

    public BookingRequest(String studentName, String room, String date, int priority) {
        this.id = counter++;
        this.studentName = studentName;
        this.room = room;
        this.date = date;
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Student: " + studentName + " | Priority: " + priority + " | Room: " + room + " | Date: " + date;
    }
}
