package campus.roombooking;

import java.util.Scanner;

public class RoomBookingMain {

    public void start(Scanner sc, RoomBookingManager manager) {
        while (true) {
            System.out.println("\n--- Room Booking System ---");
            System.out.println("1. Add Booking Request");
            System.out.println("2. Sort & Queue Requests");
            System.out.println("3. Process Next Request");
            System.out.println("4. View Unsorted Requests");
            System.out.println("5. View Queue");
            System.out.println("6. Undo Last Action");
            System.out.println("7. Redo Last Action");
            System.out.println("0. Back to Main Menu");
            System.out.print("Choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter priority (1 = high, 2 = med, 3 = low): ");
                    int p = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter room: ");
                    String room = sc.nextLine();
                    System.out.print("Enter date: ");
                    String date = sc.nextLine();
                    manager.addRequest(name, room, date, p);
                    break;
                case 2:
                    manager.sortAndQueue();
                    break;
                case 3:
                    manager.processNextRequest();
                    break;
                case 4:
                    manager.viewUnsorted();
                    break;
                case 5:
                    manager.viewQueue();
                    break;
                case 6:
                    manager.undo();
                    break;
                case 7:
                    manager.redo();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
