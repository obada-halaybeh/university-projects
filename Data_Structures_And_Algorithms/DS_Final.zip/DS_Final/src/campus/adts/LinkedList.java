package campus.adts;

public class LinkedList<T> {

	private Node<T> head;
	private Node<T> tail;
	private int size;

	public void add(T data) {
		addAt(size, data);
	}

	public void addFirst(T data) {
		Node<T> newnode = new Node<>(data);
		newnode.next = head;
		head = newnode;
		if (tail == null) {
			tail = newnode;
		}
		size++;
	}

	public void addAt(int index, T data) {
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			addFirst(data);
		} else if (index == size) {
			Node<T> newNode = new Node<>(data);
			tail.next = newNode;
			tail = newNode;
			size++;
		} else {
			Node<T> newnode = new Node<>(data);
			Node<T> p = head;
			for (int i = 0; i < index - 1; i++) {
				p = p.next;
			}
			newnode.next = p.next;
			p.next = newnode;
			size++;
		}
	}

	public T get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		Node<T> p = head;
		for (int i = 0; i < index; i++) {
			p = p.next;
		}
		return p.data;
	}

	public void remove(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			head = head.next;
		} else {
			Node<T> p = head;
			for (int i = 0; i < index - 1; i++) {
				p = p.next;
			}
			p.next = p.next.next;
		}
		size--;
	}

	public int size() {
		return size;
	}
}
