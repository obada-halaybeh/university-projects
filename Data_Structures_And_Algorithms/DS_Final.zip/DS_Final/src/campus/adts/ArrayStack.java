package campus.adts;

public class ArrayStack<T> {
	private ArrayList<T> list;
	
	public ArrayStack(int length) {
		list = new ArrayList<>(length);
	}

	public void push(T item) {
		list.add(item);
	}

	public T pop() {
		if (isEmpty()) {
			throw new RuntimeException("Stack is empty");
		}
		T value = list.get(size() - 1);
		list.remove(size() - 1);
		return value;
	}

	public T peek() {
		if (isEmpty()) {
			throw new RuntimeException("Stack is empty");
		}
		return list.get(size() - 1);
	}

	public boolean isEmpty() {
		return size() == 0;
	}
	
    public void clear() {
        while (!isEmpty()) {
            pop();
        }
    }

    public int size() {
        return list.size();
    }
	

}
