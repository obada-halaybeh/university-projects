package campus.adts;


public class BST<T extends Comparable<T>> {

    private BSTNode<T> root;

    public void insert(T data) {
        BSTNode<T> newNode = new BSTNode<>(data);
        if (root == null) {
            root = newNode;
            return;
        }

        BSTNode<T> current = root;
        BSTNode<T> parent = null;

        while (current != null) {
            parent = current;
            if (data.compareTo(current.data) < 0) {
                current = current.left;
            } else if (data.compareTo(current.data) > 0) {
                current = current.right;
            } else {
                
                return;
            }
        }

        if (data.compareTo(parent.data) < 0) {
            parent.left = newNode;
        } else {
            parent.right = newNode;
        }
    }

    public void delete(T data) {
        BSTNode<T> current = root;
        BSTNode<T> parent = null;
        
        // Find the node
        while (current != null && !current.data.equals(data)) {
            parent = current;
            if (data.compareTo(current.data) < 0) {
                current = current.left;
            } else {
                current = current.right;
            }
        }
        
        if (current == null) return; // Node not found
        
        // Case 1 Node has no children
        if (current.left == null && current.right == null) {
            if (current == root) {
                root = null;
            } else if (parent.left == current) {
                parent.left = null;
            } else {
                parent.right = null;
            }
        }
        // Case 2 Node has one child
        else if (current.left == null) {
            if (current == root) {
                root = current.right;
            } else if (parent.left == current) {
                parent.left = current.right;
            } else {
                parent.right = current.right;
            }
        } else if (current.right == null) {
            if (current == root) {
                root = current.left;
            } else if (parent.left == current) {
                parent.left = current.left;
            } else {
                parent.right = current.left;
            }
        }
        // Case 3 Node has two children
        else {
            BSTNode<T> successorParent = current;
            BSTNode<T> successor = current.right;
            
            while (successor.left != null) {
                successorParent = successor;
                successor = successor.left;
            }
            
            current.data = successor.data;
            
            if (successorParent.left == successor) {
                successorParent.left = successor.right;
            } else {
                successorParent.right = successor.right;
            }
        }
    }

    public boolean search(T data) {
        BSTNode<T> current = root;
        while (current != null) {
            int cmp = data.compareTo(current.data);
            if (cmp == 0) {
                return true;
            } else if (cmp < 0) {
                current = current.left;
            } else {
                current = current.right;
            }
        }
        return false;
    }




}