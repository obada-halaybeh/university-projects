package campus.adts;

public class ArrayQueue<T> {

	private Object[] array;
	private int front;
	private int rear;
	private int size;

	public ArrayQueue(int length) {
		array = new Object[length];
		front = -1;
		rear = -1;
		size = 0;
	}

	public void enqueue(T item) {
		if (size == array.length) {
			resize();
		}
		if (isEmpty()) {
			rear = 0;
			front = 0;
			array[rear] = item;
		} else {
			rear = (rear + 1) % array.length;
			array[rear] = item;
		}
		size++;
	}

	public T dequeue() {
		T value;
		if (isEmpty()) {
			throw new RuntimeException("Queue is empty");
		}
		if (rear == front) {
			value = (T) array[front];
			array[front] = null;
			front = -1;
			rear = -1;
		} else {
			value = (T) array[front];
			array[front] = null;
			front = (front + 1) % array.length;
		}
		size--;
		return value;
	}

	public T peek() {
		if (isEmpty()) {
			throw new RuntimeException("Queue is empty");
		}
		return (T) array[front];
	}

	public boolean isEmpty() {
		return (front == -1 && rear == -1);
	}

	public int size() {
		return size;
	}

	private void resize() {
		Object[] newArray = new Object[array.length * 2];
		for (int i = 0; i < size; i++) {
			newArray[i] = array[(front + i) % array.length];
		}
		array = newArray;
		front = 0;
		rear = size - 1;
	}

	public void printAll() {
		if (isEmpty()) {
			System.out.println("Queue is empty.");
			return;
		}
		for (int i = 0; i < size; i++) {
			int index = (front + i) % array.length;
			System.out.println(array[index]);
		}
	}

}
