package campus.adts;

public  class ArrayList<T> {

	private Object[] array;
	private int size;

	public ArrayList(int length) {
		array = new Object[length];
		size = 0;
	}

	public void add(T element) {
		addAt(size, element);
	}

	public void addFirst(T element) {
		addAt(0, element);
	}

	public void addAt(int index, T element) {
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		if (size == array.length) {
			resize();
		}
		if (index != size) {
			for (int i = size; i > index; i--) {
				array[i] = array[i - 1];
			}
		}
		array[index] = element;
		size++;
	}

	public T get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		return (T) array[index];
	}

	public void remove(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		for (int i = index; i < size - 1; i++) {
			array[i] = array[i + 1];
		}
		array[--size] = null;
	}

	public int size() {
		return size;
	}

	private void resize() {
		Object[] tempArray = new Object[array.length * 2];
		for (int i = 0; i < size; i++) {
			tempArray[i] = array[i];
		}
		array = tempArray;
	}

}
