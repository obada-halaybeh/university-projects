package campus.adts;

public class BSTNode<T> {
	T data;
	BSTNode<T> left;
	BSTNode<T> right;

	public BSTNode(T data) {
		this.data = data;
		left = right = null;
	}
}
