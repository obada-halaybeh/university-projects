package campus.locker;

import java.util.Scanner;

public class LockerMain {

    public void start(Scanner sc, LockerManager manager) {
        while (true) {
            System.out.println("\n--- Locker Management ---");
            System.out.println("1. Register Locker");
            System.out.println("2. Remove Locker");
            System.out.println("3. Lookup Locker");
            System.out.println("4. Undo Last Action");
            System.out.println("5. Redo Last Action");
            System.out.println("0. Back to Main Menu");
            System.out.print("Choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int studentId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Locker Number: ");
                    String lockerNumber = sc.nextLine();
                    manager.registerLocker(studentId, lockerNumber);
                    break;
                case 2:
                    System.out.print("Enter Student ID to remove: ");
                    studentId = sc.nextInt();
                    manager.removeLocker(studentId);
                    break;
                case 3:
                    System.out.print("Enter Student ID to lookup: ");
                    studentId = sc.nextInt();
                    manager.lookupLocker(studentId);
                    break;
                case 4:
                    manager.undo();
                    break;
                case 5:
                    manager.redo();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
