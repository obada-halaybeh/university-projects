package campus.locker;

import campus.adts.BST;
import campus.undoRedoSystem.Action;
import campus.undoRedoSystem.UndoRedoManager;


public class LockerManager {

    private BST<Locker> lockerBST;
    private UndoRedoManager undoRedo;

    public LockerManager() {
        lockerBST = new BST<>();
        undoRedo = new UndoRedoManager();
    }


    public void registerLocker(int studentId, String lockerNumber) {
        Locker newLocker = new Locker(studentId, lockerNumber);
        lockerBST.insert(newLocker);
        undoRedo.recordAction(new Action("register", newLocker));
        System.out.println("Locker registered: " + newLocker);
    }


    public void removeLocker(int studentId) {
        Locker lockerToRemove = new Locker(studentId, null);
        lockerBST.delete(lockerToRemove);
        undoRedo.recordAction(new Action("remove", lockerToRemove));
        System.out.println("Locker removed for Student ID: " + studentId);
    }


    public void lookupLocker(int studentId) {
        Locker lockerToSearch = new Locker(studentId, null);
        boolean found = lockerBST.search(lockerToSearch);
        if (found) {
            System.out.println("Locker found for Student ID: " + studentId);
        } else {
            System.out.println("No locker found for Student ID: " + studentId);
        }
    }


    public void undo() {
        Action action = undoRedo.undo();
        if (action == null) return;

        Locker locker = (Locker) action.getData();
        if (action.getType().equals("register")) {
            lockerBST.delete(locker);
            System.out.println("Undo: removed " + locker);
        } else if (action.getType().equals("remove")) {
            lockerBST.insert(locker);
            System.out.println("Undo: re-added " + locker);
        }
    }


    public void redo() {
        Action action = undoRedo.redo();
        if (action == null) return;

        Locker locker = (Locker) action.getData();
        if (action.getType().equals("register")) {
            lockerBST.insert(locker);
            System.out.println("Redo: re-registered " + locker);
        } else if (action.getType().equals("remove")) {
            lockerBST.delete(locker);
            System.out.println("Redo: re-removed " + locker);
        }
    }
}
