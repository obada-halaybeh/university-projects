package campus.locker;

public class Locker implements Comparable<Locker> {

    private int studentId;
    private String lockerNumber;

    public Locker(int studentId, String lockerNumber) {
        this.studentId = studentId;
        this.lockerNumber = lockerNumber;
    }

    public int getStudentId() {
        return studentId;
    }

    public String getLockerNumber() {
        return lockerNumber;
    }

    @Override
    public int compareTo(Locker other) {
        return Integer.compare(this.studentId, other.studentId);
    }

    @Override
    public String toString() {
        return "Locker " + lockerNumber + " (Student ID: " + studentId + ")";
    }
}
