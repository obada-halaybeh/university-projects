package campus.event;

public class Student {
    private static int counter = 1;
    private int id;
    private String name;
    private String event;

    public Student(String name, String event) {
        this.id = counter++;
        this.name = name;
        this.event = event;
    }

    public int getId() {
        return id;
    }

    public String toString() {
        return "ID: " + id + " | Name: " + name + " | Event: " + event;
    }
}
