package campus.event;

import java.util.Scanner;

public class EventRegistrationMain {

    public void start(Scanner sc, EventRegistrationManager manager) {
        while (true) {
            System.out.println("\n--- Event Registration ---");
            System.out.println("1. Register Student");
            System.out.println("2. View All Registrations");
            System.out.println("3. Process Next Student");
            System.out.println("4. Undo Last Action");
            System.out.println("5. Redo Last Action");
            System.out.println("0. Back to Main Menu");
            System.out.print("Choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter event name: ");
                    String event = sc.nextLine();
                    manager.registerStudent(name, event);
                    break;
                case 2:
                    manager.viewAll();
                    break;
                case 3:
                    manager.processNextStudent();
                    break;
                case 4:
                    manager.undo();
                    break;
                case 5:
                    manager.redo();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
