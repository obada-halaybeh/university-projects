package campus.event;

import campus.adts.ArrayQueue;
import campus.undoRedoSystem.Action;
import campus.undoRedoSystem.UndoRedoManager;


public class EventRegistrationManager {

    private ArrayQueue<Student> queue;
    private UndoRedoManager undoRedo;

    public EventRegistrationManager() {
        queue = new ArrayQueue<>(100);
        undoRedo = new UndoRedoManager();
    }

    public void registerStudent(String name, String eventName) {
        Student student = new Student(name, eventName);
        queue.enqueue(student);
        undoRedo.recordAction(new Action("register", student));
        System.out.println("Registered: " + student);
    }

    public void viewAll() {
        queue.printAll();
    }

    public void processNextStudent() {
        if (queue.isEmpty()) {
            System.out.println("No students to process.");
            return;
        }
        Student student = queue.dequeue();
        undoRedo.recordAction(new Action("process", student));
        System.out.println("Processing: " + student);
    }

    public void undo() {
        Action action = undoRedo.undo();
        if (action == null) return;

        Student s = (Student) action.getData();
        if (action.getType().equals("register")) {
            ArrayQueue<Student> temp = new ArrayQueue<>(100);
            while (!queue.isEmpty()) {
                Student current = queue.dequeue();
                if (current.getId() != s.getId()) {
                    temp.enqueue(current);
                }
            }
            queue = temp;
            System.out.println("Undo: removed " + s);
        } else if (action.getType().equals("process")) {
            queue.enqueue(s);
            System.out.println("Undo: re-added " + s);
        }
    }

    public void redo() {
        Action action = undoRedo.redo();
        if (action == null) return;

        Student s = (Student) action.getData();
        if (action.getType().equals("register")) {
            queue.enqueue(s);
            System.out.println("Redo: re-registered " + s);
        } else if (action.getType().equals("process")) {
            ArrayQueue<Student> temp = new ArrayQueue<>(100);
            while (!queue.isEmpty()) {
                Student current = queue.dequeue();
                if (current.getId() != s.getId()) {
                    temp.enqueue(current);
                }
            }
            queue = temp;
            System.out.println("Redo: re-processed " + s);
        }
    }
}
