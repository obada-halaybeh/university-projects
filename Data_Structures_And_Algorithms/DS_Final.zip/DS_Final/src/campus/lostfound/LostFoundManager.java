package campus.lostfound;

import campus.adts.LinkedList;
import campus.undoRedoSystem.Action;
import campus.undoRedoSystem.UndoRedoManager;

public class LostFoundManager {

	private LinkedList<LostFoundItem> itemList;
	private UndoRedoManager undoRedo;

	public LostFoundManager() {
		itemList = new LinkedList<>();
		undoRedo = new UndoRedoManager();
	}

	public void addItem(String description, String date, String location) {
		LostFoundItem item = new LostFoundItem(description, date, location);
		itemList.addFirst(item);
		undoRedo.recordAction(new Action("add", item));
		System.out.println("Item added: " + item);
	}

	public void removeItem(int id) {
		for (int i = 0; i < itemList.size(); i++) {
			LostFoundItem item = itemList.get(i);
			if (item.getId() == id) {
				itemList.remove(i);
				undoRedo.recordAction(new Action("remove", item));
				System.out.println("Item removed: " + item);
				return;
			}
		}
		System.out.println("No item matches the given details.");
	}

	public void viewAll() {
		if (itemList.size() == 0) {
			System.out.println("No lost/found items.");
			return;
		}
		for (int i = 0; i < itemList.size(); i++) {
			System.out.println(itemList.get(i));
		}
	}

	public void undo() {
		Action action = undoRedo.undo();
		if (action == null)
			return;

		LostFoundItem item = (LostFoundItem) action.getData();
		if (action.getType().equals("add")) {
			// Remove item by ID
			for (int i = 0; i < itemList.size(); i++) {
				if (itemList.get(i).getId() == item.getId()) {
					itemList.remove(i);
					System.out.println("Undo: removed item " + item);
					return;
				}
			}
		} else if (action.getType().equals("remove")) {
			itemList.add(item);
			System.out.println("Undo: re-added item " + item);
		}
	}

	public void redo() {
		Action action = undoRedo.redo();
		if (action == null)
			return;

		LostFoundItem item = (LostFoundItem) action.getData();
		if (action.getType().equals("add")) {
			itemList.add(item);
			System.out.println("Redo: re-added item " + item);
		} else if (action.getType().equals("remove")) {
			for (int i = 0; i < itemList.size(); i++) {
				if (itemList.get(i).getId() == item.getId()) {
					itemList.remove(i);
					System.out.println("Redo: removed item " + item);
					return;
				}
			}
		}
	}
}
