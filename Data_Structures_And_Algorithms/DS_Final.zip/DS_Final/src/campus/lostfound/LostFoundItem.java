package campus.lostfound;

public class LostFoundItem {
	private static int idCounter = 1;
	private int id;
	private String description;
	private String date;
	private String location;

	public LostFoundItem(String description, String date, String location) {
		this.id = idCounter++;
		this.description = description;
		this.date = date;
		this.location = location;
	}

	public int getId() {
		return id;
	}

	
	 public String toString() {
	        return "ID: " + id + " | Description: " + description + " | Date: " + date + " | Location: " + location;
	    }

	public void setId(int id) {
		this.id = id;
	}
}
