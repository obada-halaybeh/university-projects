package campus.lostfound;

import java.util.Scanner;

public class LostFoundMain {

    public void start(Scanner sc, LostFoundManager manager) {
        while (true) {
            System.out.println("\n--- Lost & Found System ---");
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item");
            System.out.println("3. View All");
            System.out.println("4. Undo Last Action");
            System.out.println("5. Redo Last Action");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter date: ");
                    String date = sc.nextLine();
                    System.out.print("Enter location: ");
                    String loc = sc.nextLine();
                    manager.addItem(desc, date, loc);
                    break;

                case 2:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    manager.removeItem(id);
                    break;

                case 3:
                    manager.viewAll();
                    break;

                case 4:
                    manager.undo();
                    break;

                case 5:
                    manager.redo();
                    break;

                case 0:
                    return;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}
