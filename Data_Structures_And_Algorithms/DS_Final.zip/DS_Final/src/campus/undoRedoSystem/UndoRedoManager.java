package campus.undoRedoSystem;

import campus.adts.ArrayStack;

public class UndoRedoManager {
    private ArrayStack<Action> undoStack;
    private ArrayStack<Action> redoStack;

    public UndoRedoManager() {
        undoStack = new ArrayStack<>(100);
        redoStack = new ArrayStack<>(100);
    }

    public void recordAction(Action action) {
        undoStack.push(action);
        redoStack.clear();
    }

    public Action undo() {
        if (undoStack.isEmpty()) {
            System.out.println("Nothing to undo.");
            return null;
        }
        Action action = undoStack.pop();
        redoStack.push(action);
        return action;
    }

    public Action redo() {
        if (redoStack.isEmpty()) {
            System.out.println("Nothing to redo.");
            return null;
        }
        Action action = redoStack.pop();
        undoStack.push(action);
        return action;
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }
}