package campus.undoRedoSystem;

public class Action {
	private String type; // add / remove
	private Object data;

	public Action(String type, Object data) {
		this.type = type;
		this.data = data;
	}

	public String getType() {
		return type;
	}

	public Object getData() {
		return data;
	}
}
