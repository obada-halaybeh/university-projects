<?php
session_start();
require 'connection.php';

$user_id = $_SESSION['user_id'];

$data = null;
if (isset($_GET['id'])) {
    $book_id = $_GET['id'];
    $sql = "SELECT * FROM book WHERE id = :book_id";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $statement->execute();
    $data = $statement->fetch();

    $commentSql = "
    SELECT *
    FROM book_reviews br
    JOIN user u ON br.user_id = u.id
    WHERE br.book_id = :book_id
    ";
    $commentStatement = $pdo->prepare($commentSql);
    $commentStatement->execute(['book_id' => $book_id]);
    $comments = $commentStatement->fetchAll();
}


if (isset($_GET['rating'])) {
    try {
        $sql = "INSERT INTO `book_reviews` (book_id, user_id,  rating, comment) VALUES (:book_id, :user_id, :rate, :comment)";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(":user_id", $_SESSION['user_id'], PDO::PARAM_INT);
        $statement->bindParam(":rate", $_GET['rating'], PDO::PARAM_INT);
        $statement->bindParam(":book_id", $_GET['id'], PDO::PARAM_INT);
        $statement->bindParam(":comment", $_GET['comment'], PDO::PARAM_STR);
        $statement->execute();


        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $_GET['id']);
        exit();
    } catch (PDOException $e) {
        error_log("Error inserting review: " . $e->getMessage());
        echo "An error occurred while submitting your review. Please try again later.";
    }
}

$pdo = null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $data ? $data['title'] : 'Book not found'; ?></title>
    <link rel="stylesheet" href="../css/reset.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/book.css">
    <link rel="stylesheet" href="../css/footer.css">
    <script src="https://kit.fontawesome.com/a4ac123e9a.js" crossorigin="anonymous"></script>
</head>

<body class="<?php echo $data['genre'] ?>">
    <div class="page-container">
        <header>
            <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-dark bg-dark  box-shadow mb-3">
                <div class="container-fluid">
                    <a class="navbar-brand">Read Realm</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target=".navbar-collapse" aria-controls="navbarSupportedContent" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="club.php">club</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">contact us</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    profile management
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item text-dark" href="profile.php">Profile</a>
                                    </li>
                                    <?php if (isset($_SESSION['user_id'])): ?>
                                        <li>
                                            <a class="dropdown-item text-dark" href="logout.php">Logout</a>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <a class="dropdown-item text-dark" href="login.php">Login</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>

        <div class="main-container">
            <main class="book-container">



                <?php
                if ($data) {
                    echo '<h1>' . $data['title'] . '</h1>
                    <img src="' . $data['image'] . '" alt="' . $data['title'] . '">
                    <p>' . nl2br($data['description']) . '</p>';
                }
                ?>
                <form action="">
                    <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                    <div class="rating-box">
                        <span onclick="gfg(1)" class="star"><i class="fa-solid fa-star"></i></span>
                        <span onclick="gfg(2)" class="star"><i class="fa-solid fa-star"></i></span>
                        <span onclick="gfg(3)" class="star"><i class="fa-solid fa-star"></i></span>
                        <span onclick="gfg(4)" class="star"><i class="fa-solid fa-star"></i></span>
                        <span onclick="gfg(5)" class="star"><i class="fa-solid fa-star"></i></span>
                        <input type="hidden" name="rating" value="" id="ratingInput">
                        <button class="rate-btn" type="submit">Rate</button>
                    </div>


            </main>

            <aside class="comment-box">
                <h2>Comments</h2>
                <?php
                if (!empty($comments)) {
                    foreach ($comments as $comment) {
                        // Only display the comment if it is not empty
                        if (!empty($comment['comment'])) {
                            echo '<div class="comment">
                        <h3>' . $comment['username'] . '</h3>
                        <p>' . $comment['comment'] . '</p>
                      </div>';
                        }
                    }
                }
                ?>
                <div class="add-comment">
                    <textarea name="comment" id="comment" cols="30" rows="10"></textarea>
                    <button class="btn">Add Comment</button>
                </div>
            </aside>
        </div>

        <footer>
            <p>&copy; 2024 Read Realm. All rights reserved.</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script src="/script/stars.js"></script>
</body>

</html>