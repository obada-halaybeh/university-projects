<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $_SESSION['alert'] = 'Please log in to access the club page.';
    header('Location: index.php');
    exit();
}
require 'connection.php';

$user_id = $_SESSION['user_id'];

$yourClub = null;


$sql = 'SELECT id_club FROM req WHERE user_id = :user_id AND status = 1';
$statement = $pdo->prepare($sql);
$statement->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$statement->execute();
$req = $statement->fetch();

if ($req) {
    $club_id = $req['id_club'];
} else {

    $sql = 'SELECT id FROM club WHERE user_id = :user_id';
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $statement->execute();
    $club = $statement->fetch();

    if ($club) {
        $club_id = $club['id'];
    }
}


if (isset($club_id)) {
    $sql = 'SELECT * FROM club WHERE id = :club_id';
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':club_id', $club_id, PDO::PARAM_INT);
    $statement->execute();
    $yourClub = $statement->fetch();
}

$search = '';
$sql = 'SELECT * FROM club LIMIT 3';

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $_GET['search'];
    $sql = 'SELECT * FROM club WHERE name LIKE :search LIMIT 3';
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
} else {
    $statement = $pdo->prepare($sql);
}
$statement->execute();
$data = $statement->fetchAll();

if (isset($_POST['club_id'])) {
    $club_id = $_POST['club_id'];


    $sql = 'SELECT * FROM req WHERE user_id = :user_id AND id_club = :club_id';
    $statement = $pdo->prepare($sql);
    $statement->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $statement->bindValue(':club_id', $club_id, PDO::PARAM_INT);
    $statement->execute();
    $existingRequest = $statement->fetch();

    if (!$existingRequest) {

        $sql = 'INSERT INTO req (user_id, id_club, status) VALUES (:user_id, :club_id, 2)';
        $statement = $pdo->prepare($sql);
        $statement->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $statement->bindValue(':club_id', $club_id, PDO::PARAM_INT);
        $statement->execute();
    }
}


$pdo = null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>clubs</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/reset.css">
    <!-- <link rel="stylesheet" href="/css/nav.css"> -->
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/club.css">

</head>

<body>
    <header>
        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-dark bg-dark  box-shadow mb-3">
            <div class="container-fluid">
                <a class="navbar-brand">Read Realm</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="club.php">club</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">contact us</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                profile management
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item text-dark" href="profile.php">Profile</a>
                                </li>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="logout.php">Logout</a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="login.php">Login</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="grid-container">

        <main class="club-card">
            <div class="form-search">
                <form action="" method="get">
                    <input type="text" placeholder="search" name="search">
                    <button type="submite">search</button>
                </form>
            </div>
            <?php
            foreach ($data as $row) {
                echo '<div class="card">
                    <div class="image-title">
                    <img src="' . $row['image'] . '" alt="Club Image">
                    <h1>' . $row['name'] . '</h1>
                </div>
                <div class="content">

                    <p> ' . ' genre: ' . $row['genre'] . '</p>
                    <form action="" method="post">
                        <button type="submit">Request</button>
                        <input type="hidden" name="user_id" id="user_id" value=" ' . $_SESSION['user_id'] . '">
                        <input type="hidden" name="club_id" id="club_id" value="' . $row['id'] . '">
                    </form>
                </div>
                </div>';
            }

            ?>

        </main>

        <aside class="side-bar">
            <div class="my-club">
                <h1>your club</h1>
                <?php if ($yourClub): ?>
                    <a href="my club.php?id=<?= $yourClub['id'] ?>">
                        <img src="<?= $yourClub['image'] ?>" alt="Club Image">
                    </a>
                <?php else: ?>
                    <p>You are not part of any club.</p>
                <?php endif; ?>
            </div>

            <div class="create-club">
                <a href="create-club.php"> create your club</a>
            </div>
        </aside>
    </div>
    <footer>
        <p>&copy; 2024 Read Realm. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

</body>

</html>