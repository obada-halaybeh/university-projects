<?php
session_start();

require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirm-password']);


    if ($password !== $confirmPassword) {
        $_SESSION['error'] = 'Passwords do not match.';
        header('Location: signup.php');
        exit();
    }

    try {

        $sql = 'SELECT COUNT(*) FROM user WHERE email = :email';
        $statement = $pdo->prepare($sql);
        $statement->execute(['email' => $email]);
        if ($statement->fetchColumn() > 0) {
            $_SESSION['error'] = 'Email is already in use.';
            header('Location: signup.php');
            exit();
        }


        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $statement = $pdo->prepare('INSERT INTO user (email, username, password) VALUES (:email, :username, :password)');
        $statement->execute([
            'email' => $email,
            'username' => $username,
            'password' => $hashedPassword,
        ]);


        $_SESSION['success'] = 'Signup successful! Please login.';
        header('Location: login.php');
        exit();

    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        header('Location: signup.php');
        exit();
    }
} else {

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/signup.css">
</head>

<body>
    <div class="signup">
        <h1>Signup</h1>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error-message">
                <?php
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>
        <form action="signup.php" method="post">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Create Password</label>
            <input type="password" name="password" id="password" required>
            <label for="confirm-password">Confirm Password</label>
            <input type="password" name="confirm-password" id="confirm-password" required>
            <input type="submit" value="Sign Up">
        </form>
    </div>
</body>

</html>