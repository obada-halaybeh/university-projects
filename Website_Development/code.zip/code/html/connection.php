<?php

$host = 'localhost';
$dbname ='book_world';
$user = 'root';
$pass='';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);


?>