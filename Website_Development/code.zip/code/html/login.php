<?php
session_start();
require 'connection.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        try {
            $sql = "SELECT * FROM user WHERE email = :email";
            $statement = $pdo->prepare($sql);
            $statement->bindParam(':email', $email, PDO::PARAM_STR);
            $statement->execute();
            $user = $statement->fetch(PDO::FETCH_ASSOC);
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                header('Location: index.php');
                exit();
            } else {
                $error = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <div class="login">
        <h1>login</h1>
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form action="" method="POST">
            <label for="email">Enter your email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Enter your password:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Login">
            <a href="signup.php">Don't have an account? Signup</a>
        </form>
    </div>
</body>

</html>