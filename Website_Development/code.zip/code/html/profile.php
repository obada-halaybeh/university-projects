<?php
require 'connection.php';
session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = '';
$password = '';
$image = '';


$sql = "SELECT * FROM user WHERE id = :user_id";
$statement = $pdo->prepare($sql);
$statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$statement->execute();
$data = $statement->fetch();

if ($data) {
    $username = $data['username'];
    $password = $data['password'];
    $image = $data['image'];
} else {
    echo 'User not found';
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete_account'])) {

        $sql = "DELETE FROM user WHERE id = :user_id";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
        $statement->execute();


        session_destroy();


        header("Location: index.php");
        exit();
    } else {

        $new_username = $_POST['username'] ?? '';
        $new_password = $_POST['password'] ?? '';
        $new_image = $_FILES['imgUpload']['name'] ?? '';


        if (!empty($new_username)) {
            $sql = "UPDATE user SET username = :username WHERE id = :user_id";
            $statement = $pdo->prepare($sql);
            $statement->bindParam(":username", $new_username, PDO::PARAM_STR);
            $statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $statement->execute();
            $username = $new_username;
        }


        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE user SET password = :password WHERE id = :user_id";
            $statement = $pdo->prepare($sql);
            $statement->bindParam(":password", $hashed_password, PDO::PARAM_STR);
            $statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $statement->execute();
        }


        if (!empty($new_image)) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["imgUpload"]["name"]);
            move_uploaded_file($_FILES["imgUpload"]["tmp_name"], $target_file);

            $sql = "UPDATE user SET image = :image WHERE id = :user_id";
            $statement = $pdo->prepare($sql);
            $statement->bindParam(":image", $target_file, PDO::PARAM_STR);
            $statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
            $statement->execute();
            $image = $target_file;
        }

        header("Location: profile.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/profile.css">
    <script src="../script/profile.js"></script>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-dark bg-dark  box-shadow mb-3">
            <div class="container-fluid">
                <a class="navbar-brand">Read Realm</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="club.php">club</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">contact us</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                profile management
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item text-dark" href="profile.php">Profile</a>
                                </li>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="logout.php">Logout</a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="login.php">Login</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="form-container">
        <!-- Display the current profile picture -->
        <img src="<?php echo !empty($image) ? $image : '../resources/default pfp.jfif'; ?>" class="profile-pic">
        <div class="form-grid">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-lable-name">
                    <label for="name">Change username</label>
                </div>
                <div class="form-name">
                    <!-- Display the current username -->
                    <input type="text" id="name" name="username" placeholder="Change name"
                        value="<?php echo $username; ?>">
                </div>
                <div class="form-lable-pass">
                    <label for="password">Change password</label>
                </div>
                <div class="form-pass">
                    <input type="password" id="password" name="password" placeholder="New password">
                </div>
                <div class="form-lable-img">
                    <label for="imgUpload">Change picture</label>
                </div>
                <div class="form-img">
                    <input type="file" id="imgUpload" name="imgUpload" accept="image/*">
                </div>
                <div class="form-submit">
                    <button type="submit" class="button" id="save">Save</button>
                </div>
                <div class="form-delete">
                    <button type="submit" class="button delete-button" id="deleteAccount" name="delete_account">Delete
                        Account</button>
                </div>

            </form>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Read Realm. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>