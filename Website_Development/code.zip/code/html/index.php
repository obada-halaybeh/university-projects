<?php
session_start();

if (isset($_SESSION['alert'])) {
    echo '<script>alert("' . $_SESSION['alert'] . '");</script>';
    unset($_SESSION['alert']);
}
require "connection.php";

$sql = "
SELECT * , AVG(rating) as AVG_rating
FROM book b
join book_reviews br
on b.id = br.book_id
group by b.id
order by AVG_rating desc
limit 3";
$statement = $pdo->prepare($sql);
$statement->execute();
$data = $statement->fetchAll();

$pdo = null;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <title>home</title>
    <link rel="stylesheet" href="../css/reset.css">

    <!-- <link rel="stylesheet" href="/css/nav.css"> -->
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=PT+Mono&display=swap" rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/home.css">


</head>

<body>
    <header>
        <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-dark bg-dark  box-shadow mb-3">
            <div class="container-fluid">
                <a class="navbar-brand">Read Realm</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="club.php">club</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">contact us</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                profile management
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item text-dark" href="profile.php">Profile</a>
                                </li>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="logout.php">Logout</a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a class="dropdown-item text-dark" href="login.php">Login</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="grid">

        <main class="container">
            <div class="card-container">
                <div class="card">
                    <a href="Fantasy.php"> <img src="/resources/fantasy-2899453_1280.jpg" alt="Fantasy Book"></a>
                    <a href="Fantasy.php" class="test">Fantasy</a>
                </div>
                <div class="card">
                    <a href="Action&Adventure.php"><img src="/resources/image1_0.jpg" alt="Action and Adventure"></a>
                    <a href="Action&Adventure.php" class="test">Action & Adventure</a>
                </div>
            </div>
        </main>
        <aside class="container2">
            <div class="container2-head">
                <h2>comming soon</h2>
            </div>
            <div class="card-container2">
                <div class="card2">
                    <img src="/resources/harry1.jpg" alt="cover image of harry potter and the sorcerers stone">
                    <h3>Harry potter and the sorcerers stone</h3>

                </div>
                <div class="card2">
                    <img src="/resources/harry2.jpg" alt="cover image of harry potter and the chamber of seacrets">
                    <h3>Harry potter and the chamber of seacrets</h3>

                </div>

                <div class="card2">
                    <img src="/resources/harry3.jpg" alt="cover image of harry potter and the prisoner of azkaban">
                    <h3>Harry potter and the prisoner of azkaban</h3>

                </div>
            </div>
        </aside>
        <aside class="container3">
            <div class="container3-head">
                <h3>Top Rated books</h3>
            </div>
            <div class="card-container3">
                <?php
                foreach ($data as $row) {
                    echo '<div class="card3"><a href="book.php?id=' . $row["book_id"] . '">
                    <img src="' . $row["image"] . '" alt="' . $row["title"] . '">
                    <h4>' . $row["title"] . '</h4>
                </a>
                </div>';
                }



                ?>
                <!-- <div class="card3">
                    <img src="/resources/lordofthering.jpg" alt="">
                    <h4>The Fellowship of the Ring</h4>
                </div> -->
            </div>

        </aside>

    </div>

    <footer>
        <p>&copy; 2024 Read Realm. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

</body>

</html>