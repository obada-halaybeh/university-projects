<?php
require 'connection.php';
session_start();
$user_id = $_SESSION['user_id'];
$club_id = $_GET['id'];


$sql = 'SELECT * FROM req
        JOIN user 
        ON req.user_id = user.id
        WHERE req.id_club = :club_id AND (req.status IS NULL OR req.status = 2)';
$statement = $pdo->prepare($sql);
$statement->bindParam(":club_id", $club_id, PDO::PARAM_INT);
$statement->execute();
$req = $statement->fetchAll();


if (isset($_POST['event-name'], $_POST['event-date'], $_POST['event-theme'])) {
    $event_name = $_POST['event-name'];
    $event_date = $_POST['event-date'];
    $event_theme = $_POST['event-theme'];
    $club_id = $_GET['id']; // Get the club ID from the URL


    $sql = "INSERT INTO events (club_id, event_name, event_date, event_theme) 
            VALUES (:club_id, :event_name, :event_date, :event_theme)";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(":club_id", $club_id, PDO::PARAM_INT);
    $statement->bindParam(":event_name", $event_name, PDO::PARAM_STR);
    $statement->bindParam(":event_date", $event_date, PDO::PARAM_STR);
    $statement->bindParam(":event_theme", $event_theme, PDO::PARAM_STR);
    $statement->execute();

    header("Location: myclub.php?id=" . $club_id);
    exit();
}

if (isset($_GET['id'])) {
    $club_id = $_GET['id'];
    $sql = "SELECT * FROM events WHERE club_id = :club_id";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(":club_id", $club_id, PDO::PARAM_INT);
    $statement->execute();
    $events = $statement->fetchAll();
}

if (isset($_GET['id'])) {
    $club_id = $_GET['id'];


    $sql_creator = "SELECT u.username 
                    FROM club c
                    JOIN user u ON c.user_id = u.id
                    WHERE c.id = :club_id";
    $statement_creator = $pdo->prepare($sql_creator);
    $statement_creator->bindParam(":club_id", $club_id, PDO::PARAM_INT);
    $statement_creator->execute();
    $creator = $statement_creator->fetch();


    $sql_members = "SELECT u.username 
                    FROM req r
                    JOIN user u ON r.user_id = u.id
                    WHERE r.id_club = :club_id AND r.status = 1";
    $statement_members = $pdo->prepare($sql_members);
    $statement_members->bindParam(":club_id", $club_id, PDO::PARAM_INT);
    $statement_members->execute();
    $members = $statement_members->fetchAll();


    $all_members = [];
    if ($creator) {
        $all_members[] = $creator;
    }
    if ($members) {
        $all_members = array_merge($all_members, $members);
    }
}

if (isset($_POST['user_id']) && isset($_POST['action'])) {
    $user_id = $_POST['user_id'];
    $action = $_POST['action']; // 'accept' or 'decline'
    $status = ($action === 'accept') ? 1 : 0;

    $sql = 'UPDATE req SET status = :status WHERE user_id = :user_id AND id_club = :club_id';
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':status', $status, PDO::PARAM_INT);
    $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $statement->bindParam(':club_id', $club_id, PDO::PARAM_INT);
    $statement->execute();


    header("Location: myclub.php?id=" . $club_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Read Realm - Your ultimate destination for exploring books, joining book clubs, and connecting with fellow book lovers.">
    <meta name="keywords" content="books, book clubs, fantasy books, action books, book reviews, Read Realm">
    <meta name="author" content="Read Realm">
    <link rel="icon" type="image/png" href="../resources/book-stack.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Club</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/my-club.css">
</head>

<body>
    <div class="page-container">
        <header>
            <nav class="navbar navbar-expand-sm navbar-toggleable-sm navbar-dark bg-dark  box-shadow mb-3">
                <div class="container-fluid">
                    <a class="navbar-brand">Read Realm</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target=".navbar-collapse" aria-controls="navbarSupportedContent" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="club.php">Club</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Contact Us</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Profile Management
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item text-dark" href="profile.php">Profile</a>
                                    </li>
                                    <?php if (isset($_SESSION['user_id'])): ?>
                                        <li>
                                            <a class="dropdown-item text-dark" href="logout.php">Logout</a>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <a class="dropdown-item text-dark" href="login.php">Login</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>

        <!-- Main Content -->
        <div class="main-content">
            <main class="main-box">
                <div class="event-box">
                    <h1>Events</h1>
                    <?php
                    if (!empty($events)) {
                        foreach ($events as $row) {
                            echo '<h2>' . $row['event_name'] . '</h2>
                            <p>' . $row['event_date'] . '<br>' . $row['event_theme'] . '</p>';
                        }
                    } else {
                        echo '<h2>No events have been set.</h2>';
                    }
                    ?>
                </div>
                <div class="create-event">
                    <h3>Create Event</h3>
                    <form action="" class="event-form" method="post">
                        <div class="form-group">
                            <label for="name">Name of the Event</label>
                            <input type="text" id="name" name="event-name" placeholder="Enter event name">
                        </div>
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="date" id="date" name="event-date">
                        </div>
                        <div class="form-group">
                            <label for="theme">Theme</label>
                            <textarea id="theme" name="event-theme" placeholder="Write a theme"></textarea>
                        </div>
                        <button type="submit" class="submit-button">Create Event</button>
                    </form>
                </div>
            </main>

            <!-- Sidebar -->
            <aside class="sidebar">
                <h3>Members</h3>
                <div class="members-list">
                    <?php
                    if (!empty($all_members)) {
                        foreach ($all_members as $row) {
                            echo '<div class="member">' . $row['username'] . '</div>';
                        }
                    } else {
                        echo '<div class="member">No members found.</div>';
                    }
                    ?>
                </div>

                <div class="req">
                    <h3>Requests</h3>
                    <div class="req-list">
                        <?php
                        foreach ($req as $row) {
                            echo $row['username'] . '<form method="post" action="">' .
                                '<div class="req-btn">' .
                                '<input type="hidden" name="user_id" value="' . $row['user_id'] . '">' .
                                '<button type="submit" name="action" value="accept">Accept</button>' .
                                '<button type="submit" name="action" value="decline">Decline</button>' .
                                '</div>' . '</form>' . '<br>';
                        }
                        ?>
                    </div>
                </div>
            </aside>
        </div>

        <footer>
            <p>&copy; 2024 Read Realm. All rights reserved.</p>
        </footer>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>