<?php
require 'connection.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


$sql = "DELETE FROM user WHERE id = :user_id";
$statement = $pdo->prepare($sql);
$statement->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$statement->execute();


session_destroy();


header("Location: index.php");
exit();
?>