package CMS;

public class DiagnosticReport {
    private static int count = 1;
    private String reportId;
    private String technicianId;
    private String findings;
    private String recommendations;
    private String relatedAppointmentId;

    public DiagnosticReport(String technicianId, String findings, String recommendations, String appointmentId) {
        this.reportId = "DR-" + (count++);
        this.technicianId = technicianId;
        this.findings = findings;
        this.recommendations = recommendations;
        this.relatedAppointmentId = appointmentId;
    }

    public String getFindings() {
        return findings;
    }
}
