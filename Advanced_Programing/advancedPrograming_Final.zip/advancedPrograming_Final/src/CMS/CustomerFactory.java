package CMS;

public class CustomerFactory {
    public static Customer createCustomer(String type, String fullName, String address, String nationalID, String contactNumber) {
        switch (type.toLowerCase()) {
            case "private":
                return new PrivateCustomer(fullName, address, nationalID, contactNumber);
            case "fleet":
                return new FleetCustomer(fullName, address, nationalID, contactNumber);
            case "staff":
                return new StaffCustomer(fullName, address, nationalID, contactNumber);
            default:
                throw new IllegalArgumentException("Unknown customer type: " + type);
        }
    }
}
