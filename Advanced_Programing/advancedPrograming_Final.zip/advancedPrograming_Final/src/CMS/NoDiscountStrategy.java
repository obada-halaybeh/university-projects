package CMS;

public class NoDiscountStrategy implements Discountable{
	public double applyDiscount(double basePrice) {
		return basePrice;
	}

}
