package CMS;

import java.util.List;

public class Mechanic extends Staff {
    public Mechanic(String fullName, String address, String nationalID, String contactNumber, String staffID) {
        super(fullName, address, nationalID, contactNumber, staffID);
    }

    public List<Appointment> viewScheduledAppointments() {
        return AppointmentList.getAllAppointments();
    }

    public void addServiceReport(Appointment appointment, String repairs, List<String> partsUsed) {
        ServiceReport report = new ServiceReport(this.staffID, repairs, partsUsed, appointment.getAppointmentId());
        appointment.setServiceReport(report);
    }
}


