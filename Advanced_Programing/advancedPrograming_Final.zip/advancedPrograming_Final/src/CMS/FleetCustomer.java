package CMS;

public class FleetCustomer extends Customer {
    public FleetCustomer(String fullName, String address, String nationalID, String contactNumber) {
        super(fullName, address, nationalID, contactNumber);
        setDiscountStrategy(new FleetDiscountStrategy());
    }
}
