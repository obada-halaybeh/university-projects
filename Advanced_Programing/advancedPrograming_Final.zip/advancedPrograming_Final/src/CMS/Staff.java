package CMS;

public abstract class Staff extends Person {
    protected String staffID;

    public Staff(String fullName, String address, String nationalID, String contactNumber, String staffID) {
        super(fullName, address, nationalID, contactNumber);
        this.staffID = staffID;
    }

    public String getStaffID() {
        return staffID;
    }
}
