package CMS;

public class PrivateCustomer extends Customer {
    public PrivateCustomer(String fullName, String address, String nationalID, String contactNumber) {
        super(fullName, address, nationalID, contactNumber);
        setDiscountStrategy(new NoDiscountStrategy());
    }
}

