package CMS;

public class StaffDiscountStrategy implements Discountable{
    public double applyDiscount(double basePrice) {
        return basePrice * 0.5;
    }

}
