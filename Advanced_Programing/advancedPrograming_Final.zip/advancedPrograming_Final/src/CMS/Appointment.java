package CMS;

import java.time.LocalTime;

public class Appointment {
	private static int count = 1;
	private final String appointmentId;
	private Customer customer;
	private Car car;
	private LocalTime appointmentTime;
	private ServiceReport serviceReport;
	private DiagnosticReport diagnosticReport;

	public Appointment(Customer customer, Car car, LocalTime appointmentTime) {
		this.appointmentId = "APT-" + (count++);
		this.customer = customer;
		this.car = car;
		this.appointmentTime = appointmentTime;
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public LocalTime getAppointmentTime() {
        return appointmentTime;
    }

	public void setServiceReport(ServiceReport report) {
		this.serviceReport = report;
	}

	public void setDiagnosticReport(DiagnosticReport report) {
		this.diagnosticReport = report;
	}

	public String getFullReport() {
		return "Appointment ID: " + appointmentId + "\nCustomer ID: " + customer.getNationalID() + "\nCar: " + car
				+ "\nTime: " + appointmentTime + "\nRepairs: "
				+ (serviceReport != null ? serviceReport.getRepairs() : "None") + "\nDiagnostics: "
				+ (diagnosticReport != null ? diagnosticReport.getFindings() : "None");
	}

	public String toString() {
		return appointmentId + " | " + customer.getFullName() + " | " + car + " @ " + appointmentTime;
	}
}
