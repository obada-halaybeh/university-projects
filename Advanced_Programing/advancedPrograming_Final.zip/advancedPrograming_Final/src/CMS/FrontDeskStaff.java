package CMS;

import java.time.LocalTime;

public class FrontDeskStaff extends Staff {
    public FrontDeskStaff(String fullName, String address, String nationalID, String contactNumber, String staffID) {
        super(fullName, address, nationalID, contactNumber, staffID);
    }

    public void registerCustomer(Customer customer, Car car) {
        CarList.addCar(car);
    }

    public boolean scheduleAppointment(Customer customer, Car car, LocalTime time) {
        return AppointmentList.addAppointment(new Appointment(customer, car, time));
    }

    public double calculateBill(Customer customer) {
        return customer.calculateBill(50.0); // base price X_X
    }

    public void printDailyAppointments() {
        for (Appointment appt : AppointmentList.getAllAppointments()) {
            System.out.println(appt);
        }
    }
}
