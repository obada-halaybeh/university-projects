package CMS;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AppointmentList {
    private static List<Appointment> appointments = new ArrayList<>();

    // Add a new appointment
    public static boolean addAppointment(Appointment appointment) {
        for (Appointment a : appointments) {
            if (a.getAppointmentTime().equals(appointment.getAppointmentTime())) {
                return false;
            }
        }
        appointments.add(appointment);
        return true;
    }



    // Return all scheduled appointments
    public static List<Appointment> getAllAppointments() {
        return appointments;
    }
}


