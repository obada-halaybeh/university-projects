package CMS;

public abstract class Customer extends Person {
    private Discountable discountStrategy;

    public Customer(String fullName, String address, String nationalID, String contactNumber) {
        super(fullName, address, nationalID, contactNumber);
    }

    public void setDiscountStrategy(Discountable discountStrategy) {
        this.discountStrategy = discountStrategy;
    }

    public double calculateBill(double basePrice) {
        return discountStrategy.applyDiscount(basePrice);
    }
}

