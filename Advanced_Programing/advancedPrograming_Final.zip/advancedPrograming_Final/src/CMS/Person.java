package CMS;

public abstract class Person {
	private String fullName;
	private String address;
	private String nationalID;
	private String contactNumber;

	public Person(String fullName, String address, String nationalID, String contactNumber) {
		this.fullName = fullName;
		this.address = address;
		this.nationalID = nationalID;
		this.contactNumber = contactNumber;
	}

	public String getFullName() {
		return fullName;
	}

	public String getAddress() {
		return address;
	}

	public String getNationalID() {
		return nationalID;
	}

	public String getContactNumber() {
		return contactNumber;
	}
}
