package CMS;

import java.util.List;

public class ServiceReport {
    private static int count = 1;
    private String reportId;
    private String mechanicId;
    private String repairs;
    private List<String> partsUsed;
    private String relatedAppointmentId;

    public ServiceReport(String mechanicId, String repairs, List<String> partsUsed, String appointmentId) {
        this.reportId = "SR-" + (count++);
        this.mechanicId = mechanicId;
        this.repairs = repairs;
        this.partsUsed = partsUsed;
        this.relatedAppointmentId = appointmentId;
    }

    public String getRepairs() {
        return repairs;
    }
}
