package CMS;

public class Technician extends Staff {
    public Technician(String fullName, String address, String nationalID, String contactNumber, String staffID) {
        super(fullName, address, nationalID, contactNumber, staffID);
    }

    public DiagnosticReport addDiagnosticResults(Appointment appointment, String issues, String recommendations) {
        DiagnosticReport report = new DiagnosticReport(this.staffID, issues, recommendations, appointment.getAppointmentId());
        appointment.setDiagnosticReport(report);
        return report;
    }

    public void generateDailyReport() {
        for (Appointment appt : AppointmentList.getAllAppointments()) {
            System.out.println(appt.getFullReport());
        }
    }
}

