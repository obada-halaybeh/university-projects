package CMS;

import java.util.*;
import java.time.LocalTime;

public class Main {
	static Scanner scanner = new Scanner(System.in);
	static Map<String, Customer> customerMap = new HashMap<>();
	static List<Staff> registeredStaff = new ArrayList<>();
	static boolean running = true;

	public static void main(String[] args) {
		while (running) {
			System.out.println("\n=== Who are you? ===");
			System.out.println("1. FrontDesk Staff");
			System.out.println("2. Mechanic");
			System.out.println("3. Technician");
			System.out.println("0. Exit");
			System.out.print("Choose: ");
			int role = scanner.nextInt();
			scanner.nextLine();

			switch (role) {
			case 1 -> frontDeskMenu();
			case 2 -> mechanicMenu();
			case 3 -> technicianMenu();
			case 0 -> running = false;
			default -> System.out.println("Invalid choice.");
			}
		}
	}

	// FRONT DESK MENU
	public static void frontDeskMenu() {
		while (true) {
			System.out.println("\n--- FrontDesk Menu ---");
			System.out.println("1. Register Customer");
			System.out.println("2. Register Car");
			System.out.println("3. Schedule Appointment");
			System.out.println("4. Calculate Bill");
			System.out.println("5. Print Daily Appointments");
			System.out.println("0. Back");
			System.out.print("Choose: ");
			int option = scanner.nextInt();
			scanner.nextLine();

			switch (option) {
			case 1 -> {
				System.out.print("Customer Type (private/fleet/staff): ");
				String type = scanner.nextLine();
				System.out.print("Full Name: ");
				String name = scanner.nextLine();
				System.out.print("Address: ");
				String address = scanner.nextLine();
				System.out.print("National ID: ");
				String id = scanner.nextLine();
				System.out.print("Phone: ");
				String phone = scanner.nextLine();
				Customer customer = ServiceFacade.registerCustomer(type, name, address, id, phone);
				customerMap.put(id, customer);
				System.out.println("Customer registered.");
			}

			case 2 -> {
				System.out.print("Owner National ID: ");
				String id = scanner.nextLine();
				Customer owner = customerMap.get(id);
				if (owner == null) {
					System.out.println("✘ Customer not found.");
					break;
				}
				System.out.print("Make: ");
				String make = scanner.nextLine();
				System.out.print("Model: ");
				String model = scanner.nextLine();
				System.out.print("Plate: ");
				String plate = scanner.nextLine();
				Car car = new Car(make, model, plate, owner);
				CarList.addCar(car);
				System.out.println("Car added.");
			}

			case 3 -> {
				System.out.print("Customer ID: ");
				String id = scanner.nextLine();
				Customer customer = customerMap.get(id);
				if (customer == null) {
					System.out.println("Customer not found.");
					break;
				}
				System.out.print("Plate Number: ");
				String plate = scanner.nextLine();
				Car selected = null;
				for (Car car : CarList.getAllCars()) {
					if (car.getPlateNumber().equalsIgnoreCase(plate)) {
						selected = car;
						break;
					}
				}
				if (selected == null) {
					System.out.println("Car not found.");
					break;
				}
				System.out.print("Time (hour, 9–17): ");
				int hour = scanner.nextInt();
				scanner.nextLine();
				if (hour < 9 || hour > 17) {
					System.out.println("Invalid time.");
					break;
				}
				boolean ok = AppointmentList.addAppointment(new Appointment(customer, selected, LocalTime.of(hour, 0)));
				System.out.println(ok ? "Appointment set." : "Time slot already booked.");
			}

			case 4 -> {
				System.out.print("Customer ID: ");
				String id = scanner.nextLine();
				Customer customer = customerMap.get(id);
				if (customer != null)
					System.out.println("Total Bill: " + ServiceFacade.generateBill(customer) + " JD");
				else
					System.out.println("Customer not found.");
			}

			case 5 -> {
				System.out.println("--- Appointments ---");
				for (Appointment a : AppointmentList.getAllAppointments()) {
					System.out.println(a);
				}
			}

			case 0 -> {
				return;
			}

			default -> System.out.println("Invalid option.");
			}
		}
	}

	// MECHANIC MENU
	public static void mechanicMenu() {
		Mechanic mechanic = new Mechanic("Default Mechanic", "HQ", "M001", "0777777777", "MECH1");
		while (true) {
			System.out.println("\n--- Mechanic Menu ---");
			System.out.println("1. View Scheduled Appointments");
			System.out.println("2. Add Service Report");
			System.out.println("0. Back");
			System.out.print("Choose: ");
			int option = scanner.nextInt();
			scanner.nextLine();

			switch (option) {
			case 1 -> {
				List<Appointment> appointments = ServiceFacade.viewAppointments(mechanic);
				for (Appointment a : appointments) {
					System.out.println(a);
				}
			}

			case 2 -> {
				System.out.print("Appointment ID: ");
				String aptId = scanner.nextLine();
				Appointment appt = null;
				for (Appointment a : AppointmentList.getAllAppointments()) {
					if (a.getAppointmentId().equalsIgnoreCase(aptId)) {
						appt = a;
						break;
					}
				}
				if (appt == null) {
					System.out.println("Not found.");
					break;
				}
				System.out.print("Repairs: ");
				String repairs = scanner.nextLine();
				System.out.print("Parts used (comma-separated): ");
				String[] parts = scanner.nextLine().split(",");
				List<String> partList = Arrays.asList(parts);

				ServiceFacade.completeService(aptId, repairs, partList, mechanic);
				System.out.println("Report added.");
			}

			case 0 -> {
				return;
			}

			default -> System.out.println("Invalid option.");
			}
		}
	}

	// TECHNICIAN MENU
	public static void technicianMenu() {
		Technician tech = new Technician("Default Tech", "Lab", "T001", "0788888888", "TECH1");
		while (true) {
			System.out.println("\n--- Technician Menu ---");
			System.out.println("1. Add Diagnostic");
			System.out.println("2. Generate Daily Report");
			System.out.println("0. Back");
			System.out.print("Choose: ");
			int option = scanner.nextInt();
			scanner.nextLine();

			switch (option) {
			case 1 -> {
				System.out.print("Appointment ID: ");
				String aptId = scanner.nextLine();
				Appointment appt = null;
				for (Appointment a : AppointmentList.getAllAppointments()) {
					if (a.getAppointmentId().equalsIgnoreCase(aptId)) {
						appt = a;
						break;
					}
				}
				if (appt == null) {
					System.out.println("Not found.");
					break;
				}
				System.out.print("Issues: ");
				String issues = scanner.nextLine();
				System.out.print("Recommendations: ");
				String recs = scanner.nextLine();

				ServiceFacade.submitDiagnostic(aptId, issues, recs, tech);
				System.out.println("Diagnostic added.");
			}

			case 2 -> tech.generateDailyReport();

			case 0 -> {
				return;
			}

			default -> System.out.println("Invalid option.");
			}
		}
	}
}
