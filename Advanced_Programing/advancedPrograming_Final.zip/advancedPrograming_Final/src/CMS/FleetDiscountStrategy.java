package CMS;

public class FleetDiscountStrategy implements Discountable{
    public double applyDiscount(double basePrice) {
        return basePrice * 0.7;
    }
}
