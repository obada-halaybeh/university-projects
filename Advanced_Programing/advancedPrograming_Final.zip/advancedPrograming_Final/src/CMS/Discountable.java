package CMS;

public interface Discountable {
	double applyDiscount(double basePrice);

}
