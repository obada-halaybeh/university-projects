package CMS;

import java.time.LocalTime;
import java.util.List;

public class ServiceFacade {

	public static void createAppointment(Customer customer, Car car, LocalTime time) {
		CarList.addCar(car);
		AppointmentList.addAppointment(new Appointment(customer, car, time));
	}

	public static double generateBill(Customer customer) {
		return customer.calculateBill(50.0); // Fixed service fee
	}

	public static Customer registerCustomer(String type, String fullName, String address, String nationalID,
			String contactNumber) {
		return CustomerFactory.createCustomer(type, fullName, address, nationalID, contactNumber);
	}

	public static void printDailyReports() {
		List<Appointment> all = AppointmentList.getAllAppointments();
		for (Appointment a : all) {
			System.out.println(a.getFullReport());
		}
	}

	public static List<Appointment> viewAppointments(Mechanic mechanic) {
		return mechanic.viewScheduledAppointments();
	}

	public static void submitDiagnostic(String appointmentId, String issues, String recommendations,
			Technician technician) {
		for (Appointment a : AppointmentList.getAllAppointments()) {
			if (a.getAppointmentId().equalsIgnoreCase(appointmentId)) {
				technician.addDiagnosticResults(a, issues, recommendations);
				break;
			}
		}
	}

	public static void completeService(String appointmentId, String repairs, List<String> parts, Mechanic mechanic) {
		for (Appointment a : AppointmentList.getAllAppointments()) {
			if (a.getAppointmentId().equalsIgnoreCase(appointmentId)) {
				mechanic.addServiceReport(a, repairs, parts);
				break;
			}
		}
	}
}
