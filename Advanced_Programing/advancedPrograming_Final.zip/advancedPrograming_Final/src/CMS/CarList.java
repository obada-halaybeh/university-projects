package CMS;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CarList {
	private static List<Car> cars = new ArrayList<>();

	// Add a new car
	public static void addCar(Car car) {
		cars.add(car);
	}

	// Return list of all cars
	public static List<Car> getAllCars() {
		return cars;
	}
}
