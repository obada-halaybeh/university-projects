package CMS;

public class StaffCustomer extends Customer {
    public StaffCustomer(String fullName, String address, String nationalID, String contactNumber) {
        super(fullName, address, nationalID, contactNumber);
        setDiscountStrategy(new StaffDiscountStrategy());
    }
}
