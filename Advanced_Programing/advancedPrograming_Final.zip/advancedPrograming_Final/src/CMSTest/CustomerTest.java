package CMSTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import CMS.Car;
import CMS.Customer;
import CMS.PrivateCustomer;

public class CustomerTest {

    private Customer privateCustomer;
    private Car car;

    @BeforeEach
    public void setup() {
        privateCustomer = new PrivateCustomer("Ali", "Amman", "1234", "0799999999");
        car = new Car("Toyota", "Corolla", "11111", privateCustomer);
    }

    @Test
    public void testValidCustomerRegistration() {
        assertEquals("Ali", privateCustomer.getFullName());
        assertEquals("11111", car.getPlateNumber());
    }

    @Test
    public void testMissingNameInCustomer() {
        Customer invalid = new PrivateCustomer("", "Amman", "1234", "0799999999");
        assertTrue(invalid.getFullName().isEmpty());
    }

    @Test
    public void testCarWithoutPlateNumber() {
        Car noPlate = new Car("Kia", "Rio", "", privateCustomer);
        assertEquals("", noPlate.getPlateNumber());
    }
}
