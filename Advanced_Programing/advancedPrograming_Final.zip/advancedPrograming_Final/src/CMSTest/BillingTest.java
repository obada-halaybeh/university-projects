package CMSTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import CMS.Customer;
import CMS.FleetCustomer;
import CMS.PrivateCustomer;
import CMS.StaffCustomer;

public class BillingTest {

    private Customer fleetCustomer;
    private Customer staffCustomer;
    private Customer privateCustomer;

    @BeforeEach
    public void setup() {
        fleetCustomer = new FleetCustomer("Fleet", "Aqaba", "300", "0700000000");
        staffCustomer = new StaffCustomer("Staff", "Madaba", "400", "0711111111");
        privateCustomer = new PrivateCustomer("Private", "Karak", "500", "0722222222");
    }

    @Test
    public void testFleetCustomerDiscount() {
        assertEquals(35.0, fleetCustomer.calculateBill(50.0), 0.01);
    }

    @Test
    public void testStaffCustomerDiscount() {
        assertEquals(25.0, staffCustomer.calculateBill(50.0), 0.01);
    }

    @Test
    public void testPrivateCustomerNoDiscount() {
        assertEquals(50.0, privateCustomer.calculateBill(50.0), 0.01);
    }
}