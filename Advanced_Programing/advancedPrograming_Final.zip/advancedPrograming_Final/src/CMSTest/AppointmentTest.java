package CMSTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import CMS.Appointment;
import CMS.AppointmentList;
import CMS.Car;
import CMS.Customer;
import CMS.PrivateCustomer;

public class AppointmentTest {

    private Customer customer;
    private Car car;

    @BeforeEach
    public void setup() {
    	
    	//AppointmentList.getAllAppointments().clear();
    	
        customer = new PrivateCustomer("Zaid", "Zarqa", "001", "0777777777");
        car = new Car("Hyundai", "Tucson", "XYZ123", customer);
    }

    @Test
    public void testScheduleValidAppointment() {
        Appointment appt = new Appointment(customer, car, LocalTime.of(10, 0));
        boolean added = AppointmentList.addAppointment(appt);
        assertTrue(added);
    }

    @Test
    public void testAppointmentOutsideWorkingHours() {
        LocalTime lateTime = LocalTime.of(18, 0);
        assertTrue(lateTime.isAfter(LocalTime.of(17, 0)));
    }

    @Test
    public void testDuplicateTimeSlotBooking() {
        Appointment appt1 = new Appointment(customer, car, LocalTime.of(11, 0));
        Appointment appt2 = new Appointment(customer, car, LocalTime.of(11, 0));
        AppointmentList.addAppointment(appt1);
        boolean result = AppointmentList.addAppointment(appt2);
        assertFalse(result);
    }
}
